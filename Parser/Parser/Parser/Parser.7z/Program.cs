﻿using Amazon;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.Runtime;
using HtmlAgilityPack;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Parser;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ConsoleApp33
{
    class Program
    {
        private static readonly AmazonDynamoDBClient dbClient = null;

        static Program()
        {
            //string dbAccessKey = Environment.GetEnvironmentVariable("db_access_key");
            //string dbSecretKey = Environment.GetEnvironmentVariable("db_secret_key");
            string dbAccessKey = "AKIAWSLP3V3G5D3WNSVC";
            string dbSecretKey = "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";
            var dbCredentials = new BasicAWSCredentials(dbAccessKey, dbSecretKey);
            dbClient = new AmazonDynamoDBClient(dbCredentials, RegionEndpoint.EUCentral1);
        }
        private static List<string> GetPostFromDb()
        {
            var attributes = new List<string>() { "id" };
            var allDocs = dbClient.ScanAsync("AllredyParsedPosts", attributes).Result;
            var resultList = new List<string>();
            foreach (var item in allDocs.Items)
            {
                resultList.Add(item["id"].S);
            }
            return resultList;
        }
        private static List<string> GetAllIdsFromFb()
        {
            string url = "https://www.facebook.com/ulanasuprun/posts/";
            HtmlDocument newPostDetector = new HtmlWeb().Load(url);
            string pageHtml = newPostDetector.DocumentNode.InnerHtml;

            MatchCollection matches = Regex.Matches(pageHtml, @"(\/ulanasuprun\/posts\/([0-9]+))");
            var postIds = new HashSet<string>();
            foreach (Match match in matches)
            {
                // /ulanasuprun/posts/3346912382015753
                var index = match.Value.LastIndexOf('/') + 1;
                var postId = match.Value.Substring(index);
                postIds.Add(postId);
            }
            return postIds.ToList();
        }
        public static void Main(string[] args)
        {
            RepostFacebookPost();
        }
        public static void RepostFacebookPost()
        {
            // Дістати з бази даних вже відправлені пости.
            List<string> alreadyPostedIds = GetPostFromDb();

            // Дістати список всіх постів з facebook.com/suprun/posts
            List<string> allIds = GetAllIdsFromFb();

            // Зясувати чи є нові пости.
            // Резутат знаходження нового посту це його id:
            string newPostFacebookId = "";
            foreach (var id in allIds)
            {
                if (!alreadyPostedIds.Contains(id))
                {
                    newPostFacebookId = id;
                    break;
                }
            }
            Post post = new Post(newPostFacebookId);
            if (post.TelegramContent.Length < 4097)
            {
                TelegramPostingMethod(post.TelegramContent, true);
                TelegramPostingImagesMethod(post.ImageUrls);
            }
            else
            {
                TelegraphPostingMethod(post.TelegraphContent);
            }
            // Зберегти в базу id поста який відправили.
            SavePostToDb(newPostFacebookId);
        }
        private static void SavePostToDb(string postId)
        {
            Table table = Table.LoadTable(dbClient, "AllredyParsedPosts");
            var item = new Document();
            item["id"] = postId;
            table.PutItemAsync(item);
        }

        static void TelegraphPostingMethod(string telegraphContent)
        {
            Dictionary<string, string> values = new Dictionary<string, string>
            {
                { "title", "Уляна Супрун" },
                { "author_name", "Уляна Супрун" },
                { "content", telegraphContent },
                { "return_content", "true" }
            };
            var client = new HttpClient();
            var content = new FormUrlEncodedContent(values);
            Task<HttpResponseMessage> task = client.PostAsync("https://api.telegra.ph/createPage?access_token=9596118885a2bafed8556475533dc09596d876fea8b39ed6d191d05d9b67&", content);
            var responseString = task.Result.Content.ReadAsStringAsync().Result;

            if (task.Result.StatusCode == System.Net.HttpStatusCode.OK)
            {
                TelegraphResponse thResponse = JsonConvert.DeserializeObject<TelegraphResponse>(responseString);
                TelegramPostingMethod(thResponse.result.url, false);
            }
        }
        static void TelegramPostingMethod(string telegramContent, bool isTelegramPost)
        {
            telegramContent = telegramContent.Replace('`', '\'');
            telegramContent = WebUtility.HtmlDecode(telegramContent);
            Dictionary<string, string> values = new Dictionary<string, string>
            {
                { "chat_id", "@stanislav_hladyshko"},
                { "parse_mode", "markdown"},
                { "text", telegramContent }
            };
            if (isTelegramPost)
            {
                values["disable_web_page_preview"] = "true";
            }
            var httpClient = new HttpClient();
            HttpContent content = new FormUrlEncodedContent(values);
            string telegramToken = "https://api.telegram.org/bot980261769:AAGPe8mb1Cuq4wWPu-JBdFnSC_nr9aW9--k/sendMessage";
            var response = httpClient.PostAsync(telegramToken, content).Result;
        }
        static void TelegramPostingImagesMethod(List<string> UrlsList)
        {
            JArray JsonMediaGroup = new JArray();
            foreach (var item in UrlsList)
            {
                JObject InputMediaPhoto = JObject.FromObject(new
                {
                    type = "photo",
                    media = item
                });
                JsonMediaGroup.Add(InputMediaPhoto);
            }
            Dictionary<string, string> values = new Dictionary<string, string>
            {
                { "chat_id", "@stanislav_hladyshko"},
                { "media", JsonMediaGroup.ToString() },
                { "disable_notification", "true" },
            };
            var httpClient = new HttpClient();
            HttpContent content = new FormUrlEncodedContent(values);
            string telegramToken = "https://api.telegram.org/bot980261769:AAGPe8mb1Cuq4wWPu-JBdFnSC_nr9aW9--k/sendMediaGroup";
            var response = httpClient.PostAsync(telegramToken, content).Result;
        }
    }
}